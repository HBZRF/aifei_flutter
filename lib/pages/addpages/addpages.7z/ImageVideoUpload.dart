import 'package:flutter/material.dart';
import 'dart:io';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';


class ImageVideoUpload extends StatefulWidget {
  @override
  _ImageVideoUploadState createState() => _ImageVideoUploadState();
}


class _ImageVideoUploadState extends State<ImageVideoUpload> {


  File imageFile;
  

  // To to get the photos from local storage
  _gallery()async{

    File selectedImage = await ImagePicker.pickImage(source: ImageSource.gallery);

    if(selectedImage != null){
      setState(() {
        imageFile = selectedImage;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.instance = ScreenUtil(width: 1080, height: 1920)..init(context);
    //这时候我们使用的尺寸是px.
    //根据屏幕宽度适配：width:ScreenUtil().setWidth(540);
    //根据屏幕高度适配：height:ScreenUtil().setHeight(200);
    //适配字体大小：fontSize：ScreenUtil().setSp(28);
    return Scaffold(
      appBar: AppBar(),
      backgroundColor: Colors.white,
    body: Container(
      color: Colors.grey[200],
      child: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(0),
          child: ListView(
            children: <Widget>[
             Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment : CrossAxisAlignment.start,
              children: <Widget>[
              Container(
                color: Colors.red,
                padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(0), ScreenUtil().setWidth(50), ScreenUtil().setWidth(0), ScreenUtil().setWidth(50)),
                child: Column(
                  children: <Widget>[
                    // Cancel Icon
                    SizedBox(height: ScreenUtil().setHeight(10)),
                    // Add photos Icons + text
                    Padding(
                      padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(10), ScreenUtil().setWidth(10), ScreenUtil().setWidth(0), ScreenUtil().setWidth(0)),
                      child: Container(
                        height: ScreenUtil().setHeight(230),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            IconButton(
                              //child: RaisedButton.icon(
                              onPressed: (){
                                _gallery();
                              },
                              icon: Icon(
                                Icons.add_to_photos,
                                color: Colors.grey,
                                size:ScreenUtil().setHeight(200),
                              ),
                            ),
                            //SizedBox(width:100,),
                            Padding(
                              padding:  EdgeInsets.fromLTRB(ScreenUtil().setWidth(140), ScreenUtil().setWidth(70), ScreenUtil().setWidth(0), ScreenUtil().setWidth(0)),
                              child: Text(
                                "Add photos",
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: ScreenUtil().setSp(78),
                                  fontWeight: FontWeight.normal
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                  ],
                ),
              ),

              SizedBox(height: ScreenUtil().setHeight(20)),
              // Title + say something
              Container(
                margin: EdgeInsets.fromLTRB(ScreenUtil().setWidth(20), ScreenUtil().setWidth(0), ScreenUtil().setWidth(20), ScreenUtil().setWidth(0)),
                height: ScreenUtil().setWidth(940),

                color: Colors.white,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
               children: <Widget>[
                 Padding(
                   padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(40), ScreenUtil().setWidth(0), ScreenUtil().setWidth(260), ScreenUtil().setWidth(0)),
                   child: Row(
                     children: <Widget>[
                       Expanded(
                         child: TextField(
                           decoration: InputDecoration(
                             hintText: "Title",
                             hintStyle: TextStyle(
                               fontSize: ScreenUtil().setSp(50),
                             ),

                           ),
                         ),
                       ),
                     ],
                   ),
                 ),

                 Padding(
                   padding:EdgeInsets.fromLTRB(ScreenUtil().setWidth(80), ScreenUtil().setWidth(0), ScreenUtil().setWidth(260), ScreenUtil().setWidth(0)),
                   child: Row(
                     children: <Widget>[
                       Expanded(

                         child: TextField(
                           keyboardType: TextInputType.multiline,
                           maxLines: null,
                           decoration: InputDecoration(
                             focusedBorder: InputBorder.none,
                             border: InputBorder.none,
                             hintText: "Say something",
                             hintStyle: TextStyle(
                               fontSize: ScreenUtil().setSp(40),
                             ),
                           ),
                         ),
                       ),
                     ],
                   ),
                 ),

               ],
                ),
              ),

             SizedBox(height:ScreenUtil().setHeight(20)),

             Padding(
               padding: EdgeInsets.fromLTRB(ScreenUtil().setWidth(30), ScreenUtil().setWidth(0), ScreenUtil().setWidth(0), ScreenUtil().setWidth(0)),
               child: Row(
                 children: <Widget>[
                   CircleAvatar(

                     backgroundColor: Colors.white,
                     radius: 37,
                     child: Column(
                       children: <Widget>[
                         IconButton(
                           onPressed:(){
                             Navigator.pushReplacementNamed(context,'/draftbox', arguments: {
                               'imageFile' : imageFile
                             });
                           },
                        iconSize: ScreenUtil().setHeight(70) ,
                           icon: Icon(Icons.drafts,),
                         ),
                         Text(
                             "Draft box",
                           style: TextStyle(
                             fontSize: ScreenUtil().setSp(30),
                           ),
                         ),
                       ],
                     ),
                   ),
                   SizedBox(width:ScreenUtil().setHeight(70)),
                   Container(
                     //color: Colors.white,
                     decoration: BoxDecoration(
                       color: Colors.white,
                       borderRadius: BorderRadius.circular(5),
                     ),
                     child: FlatButton(
                       onPressed: () {},
                       child: Text(
                         "Upload",
                         style: TextStyle(
                           fontSize: ScreenUtil().setSp(40),
                           fontWeight: FontWeight.bold,
                         ),
                       ),
                     ),
                   ),
                 ],
               ),
             )
            ]
         ),
            ],
          ),
        ),
      ),
    ),
    );
  }
}
