

//url info
var url_checkupdate = 'http://m.nokia-nsb.com/checkupdate/';